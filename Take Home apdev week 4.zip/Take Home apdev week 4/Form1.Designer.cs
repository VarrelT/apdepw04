﻿namespace Take_Home_apdev_week_4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_1 = new System.Windows.Forms.Label();
            this.lbl_2 = new System.Windows.Forms.Label();
            this.lbl_3 = new System.Windows.Forms.Label();
            this.lbl_4 = new System.Windows.Forms.Label();
            this.lbl_5 = new System.Windows.Forms.Label();
            this.lbl_6 = new System.Windows.Forms.Label();
            this.lbl_7 = new System.Windows.Forms.Label();
            this.lbl_8 = new System.Windows.Forms.Label();
            this.lbl_9 = new System.Windows.Forms.Label();
            this.lbl_10 = new System.Windows.Forms.Label();
            this.lbl_11 = new System.Windows.Forms.Label();
            this.cb_ChooseCountry = new System.Windows.Forms.ComboBox();
            this.cb_ChooseTeam = new System.Windows.Forms.ComboBox();
            this.cb_PlayerPosisition = new System.Windows.Forms.ComboBox();
            this.tb_AddTeamName = new System.Windows.Forms.TextBox();
            this.tb_AddCountry = new System.Windows.Forms.TextBox();
            this.tb_AddCity = new System.Windows.Forms.TextBox();
            this.tb_AddPlayerName = new System.Windows.Forms.TextBox();
            this.tb_AddPlayerNumber = new System.Windows.Forms.TextBox();
            this.lb_listplayers = new System.Windows.Forms.ListBox();
            this.btn_AddingTeam = new System.Windows.Forms.Button();
            this.btn_AddingPLayers = new System.Windows.Forms.Button();
            this.btn_RemovePLayer = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_1
            // 
            this.lbl_1.AutoSize = true;
            this.lbl_1.Location = new System.Drawing.Point(26, 52);
            this.lbl_1.Name = "lbl_1";
            this.lbl_1.Size = new System.Drawing.Size(132, 20);
            this.lbl_1.TabIndex = 0;
            this.lbl_1.Text = "Soccer Team List";
            // 
            // lbl_2
            // 
            this.lbl_2.AutoSize = true;
            this.lbl_2.Location = new System.Drawing.Point(27, 104);
            this.lbl_2.Name = "lbl_2";
            this.lbl_2.Size = new System.Drawing.Size(131, 20);
            this.lbl_2.TabIndex = 1;
            this.lbl_2.Text = "Choose Country :";
            // 
            // lbl_3
            // 
            this.lbl_3.AutoSize = true;
            this.lbl_3.Location = new System.Drawing.Point(27, 136);
            this.lbl_3.Name = "lbl_3";
            this.lbl_3.Size = new System.Drawing.Size(116, 20);
            this.lbl_3.TabIndex = 2;
            this.lbl_3.Text = "Choose Team :";
            // 
            // lbl_4
            // 
            this.lbl_4.AutoSize = true;
            this.lbl_4.Location = new System.Drawing.Point(468, 52);
            this.lbl_4.Name = "lbl_4";
            this.lbl_4.Size = new System.Drawing.Size(103, 20);
            this.lbl_4.TabIndex = 3;
            this.lbl_4.Text = "Adding Team";
            // 
            // lbl_5
            // 
            this.lbl_5.AutoSize = true;
            this.lbl_5.Location = new System.Drawing.Point(393, 104);
            this.lbl_5.Name = "lbl_5";
            this.lbl_5.Size = new System.Drawing.Size(99, 20);
            this.lbl_5.TabIndex = 4;
            this.lbl_5.Text = "Team Name:";
            // 
            // lbl_6
            // 
            this.lbl_6.AutoSize = true;
            this.lbl_6.Location = new System.Drawing.Point(393, 136);
            this.lbl_6.Name = "lbl_6";
            this.lbl_6.Size = new System.Drawing.Size(112, 20);
            this.lbl_6.TabIndex = 5;
            this.lbl_6.Text = "Team Country:";
            // 
            // lbl_7
            // 
            this.lbl_7.AutoSize = true;
            this.lbl_7.Location = new System.Drawing.Point(393, 170);
            this.lbl_7.Name = "lbl_7";
            this.lbl_7.Size = new System.Drawing.Size(83, 20);
            this.lbl_7.TabIndex = 6;
            this.lbl_7.Text = "Team City:";
            // 
            // lbl_8
            // 
            this.lbl_8.AutoSize = true;
            this.lbl_8.Location = new System.Drawing.Point(805, 52);
            this.lbl_8.Name = "lbl_8";
            this.lbl_8.Size = new System.Drawing.Size(114, 20);
            this.lbl_8.TabIndex = 7;
            this.lbl_8.Text = "Adding Players";
            // 
            // lbl_9
            // 
            this.lbl_9.AutoSize = true;
            this.lbl_9.Location = new System.Drawing.Point(729, 104);
            this.lbl_9.Name = "lbl_9";
            this.lbl_9.Size = new System.Drawing.Size(102, 20);
            this.lbl_9.TabIndex = 8;
            this.lbl_9.Text = "Player Name:";
            // 
            // lbl_10
            // 
            this.lbl_10.AutoSize = true;
            this.lbl_10.Location = new System.Drawing.Point(729, 136);
            this.lbl_10.Name = "lbl_10";
            this.lbl_10.Size = new System.Drawing.Size(116, 20);
            this.lbl_10.TabIndex = 9;
            this.lbl_10.Text = "Player Number:";
            // 
            // lbl_11
            // 
            this.lbl_11.AutoSize = true;
            this.lbl_11.Location = new System.Drawing.Point(729, 170);
            this.lbl_11.Name = "lbl_11";
            this.lbl_11.Size = new System.Drawing.Size(127, 20);
            this.lbl_11.TabIndex = 10;
            this.lbl_11.Text = "Player Posisition:";
            // 
            // cb_ChooseCountry
            // 
            this.cb_ChooseCountry.FormattingEnabled = true;
            this.cb_ChooseCountry.Location = new System.Drawing.Point(164, 101);
            this.cb_ChooseCountry.Name = "cb_ChooseCountry";
            this.cb_ChooseCountry.Size = new System.Drawing.Size(161, 28);
            this.cb_ChooseCountry.TabIndex = 11;
            this.cb_ChooseCountry.SelectedIndexChanged += new System.EventHandler(this.cb_ChooseCountry_SelectedIndexChanged);
            // 
            // cb_ChooseTeam
            // 
            this.cb_ChooseTeam.FormattingEnabled = true;
            this.cb_ChooseTeam.Location = new System.Drawing.Point(164, 136);
            this.cb_ChooseTeam.Name = "cb_ChooseTeam";
            this.cb_ChooseTeam.Size = new System.Drawing.Size(161, 28);
            this.cb_ChooseTeam.TabIndex = 12;
            this.cb_ChooseTeam.SelectedIndexChanged += new System.EventHandler(this.cb_ChooseTeam_SelectedIndexChanged);
            // 
            // cb_PlayerPosisition
            // 
            this.cb_PlayerPosisition.FormattingEnabled = true;
            this.cb_PlayerPosisition.Items.AddRange(new object[] {
            "FW",
            "MF",
            "DF",
            "GK"});
            this.cb_PlayerPosisition.Location = new System.Drawing.Point(862, 167);
            this.cb_PlayerPosisition.Name = "cb_PlayerPosisition";
            this.cb_PlayerPosisition.Size = new System.Drawing.Size(161, 28);
            this.cb_PlayerPosisition.TabIndex = 13;
            // 
            // tb_AddTeamName
            // 
            this.tb_AddTeamName.Location = new System.Drawing.Point(517, 104);
            this.tb_AddTeamName.Name = "tb_AddTeamName";
            this.tb_AddTeamName.Size = new System.Drawing.Size(161, 26);
            this.tb_AddTeamName.TabIndex = 14;
            // 
            // tb_AddCountry
            // 
            this.tb_AddCountry.Location = new System.Drawing.Point(517, 138);
            this.tb_AddCountry.Name = "tb_AddCountry";
            this.tb_AddCountry.Size = new System.Drawing.Size(161, 26);
            this.tb_AddCountry.TabIndex = 15;
            // 
            // tb_AddCity
            // 
            this.tb_AddCity.Location = new System.Drawing.Point(517, 170);
            this.tb_AddCity.Name = "tb_AddCity";
            this.tb_AddCity.Size = new System.Drawing.Size(161, 26);
            this.tb_AddCity.TabIndex = 16;
            // 
            // tb_AddPlayerName
            // 
            this.tb_AddPlayerName.Location = new System.Drawing.Point(862, 104);
            this.tb_AddPlayerName.Name = "tb_AddPlayerName";
            this.tb_AddPlayerName.Size = new System.Drawing.Size(161, 26);
            this.tb_AddPlayerName.TabIndex = 17;
            // 
            // tb_AddPlayerNumber
            // 
            this.tb_AddPlayerNumber.Location = new System.Drawing.Point(862, 136);
            this.tb_AddPlayerNumber.Name = "tb_AddPlayerNumber";
            this.tb_AddPlayerNumber.Size = new System.Drawing.Size(161, 26);
            this.tb_AddPlayerNumber.TabIndex = 18;
            // 
            // lb_listplayers
            // 
            this.lb_listplayers.FormattingEnabled = true;
            this.lb_listplayers.ItemHeight = 20;
            this.lb_listplayers.Location = new System.Drawing.Point(30, 218);
            this.lb_listplayers.Name = "lb_listplayers";
            this.lb_listplayers.Size = new System.Drawing.Size(295, 164);
            this.lb_listplayers.TabIndex = 19;
            // 
            // btn_AddingTeam
            // 
            this.btn_AddingTeam.Location = new System.Drawing.Point(517, 218);
            this.btn_AddingTeam.Name = "btn_AddingTeam";
            this.btn_AddingTeam.Size = new System.Drawing.Size(96, 37);
            this.btn_AddingTeam.TabIndex = 20;
            this.btn_AddingTeam.Text = "Add";
            this.btn_AddingTeam.UseVisualStyleBackColor = true;
            this.btn_AddingTeam.Click += new System.EventHandler(this.btn_AddingTeam_Click);
            // 
            // btn_AddingPLayers
            // 
            this.btn_AddingPLayers.Location = new System.Drawing.Point(862, 218);
            this.btn_AddingPLayers.Name = "btn_AddingPLayers";
            this.btn_AddingPLayers.Size = new System.Drawing.Size(96, 37);
            this.btn_AddingPLayers.TabIndex = 21;
            this.btn_AddingPLayers.Text = "Add";
            this.btn_AddingPLayers.UseVisualStyleBackColor = true;
            this.btn_AddingPLayers.Click += new System.EventHandler(this.btn_AddingPLayers_Click);
            // 
            // btn_RemovePLayer
            // 
            this.btn_RemovePLayer.Location = new System.Drawing.Point(31, 406);
            this.btn_RemovePLayer.Name = "btn_RemovePLayer";
            this.btn_RemovePLayer.Size = new System.Drawing.Size(112, 32);
            this.btn_RemovePLayer.TabIndex = 22;
            this.btn_RemovePLayer.Text = "Remove";
            this.btn_RemovePLayer.UseVisualStyleBackColor = true;
            this.btn_RemovePLayer.Click += new System.EventHandler(this.btn_RemovePLayer_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1083, 450);
            this.Controls.Add(this.btn_RemovePLayer);
            this.Controls.Add(this.btn_AddingPLayers);
            this.Controls.Add(this.btn_AddingTeam);
            this.Controls.Add(this.lb_listplayers);
            this.Controls.Add(this.tb_AddPlayerNumber);
            this.Controls.Add(this.tb_AddPlayerName);
            this.Controls.Add(this.tb_AddCity);
            this.Controls.Add(this.tb_AddCountry);
            this.Controls.Add(this.tb_AddTeamName);
            this.Controls.Add(this.cb_PlayerPosisition);
            this.Controls.Add(this.cb_ChooseTeam);
            this.Controls.Add(this.cb_ChooseCountry);
            this.Controls.Add(this.lbl_11);
            this.Controls.Add(this.lbl_10);
            this.Controls.Add(this.lbl_9);
            this.Controls.Add(this.lbl_8);
            this.Controls.Add(this.lbl_7);
            this.Controls.Add(this.lbl_6);
            this.Controls.Add(this.lbl_5);
            this.Controls.Add(this.lbl_4);
            this.Controls.Add(this.lbl_3);
            this.Controls.Add(this.lbl_2);
            this.Controls.Add(this.lbl_1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_1;
        private System.Windows.Forms.Label lbl_2;
        private System.Windows.Forms.Label lbl_3;
        private System.Windows.Forms.Label lbl_4;
        private System.Windows.Forms.Label lbl_5;
        private System.Windows.Forms.Label lbl_6;
        private System.Windows.Forms.Label lbl_7;
        private System.Windows.Forms.Label lbl_8;
        private System.Windows.Forms.Label lbl_9;
        private System.Windows.Forms.Label lbl_10;
        private System.Windows.Forms.Label lbl_11;
        private System.Windows.Forms.ComboBox cb_ChooseCountry;
        private System.Windows.Forms.ComboBox cb_ChooseTeam;
        private System.Windows.Forms.ComboBox cb_PlayerPosisition;
        private System.Windows.Forms.TextBox tb_AddTeamName;
        private System.Windows.Forms.TextBox tb_AddCountry;
        private System.Windows.Forms.TextBox tb_AddCity;
        private System.Windows.Forms.TextBox tb_AddPlayerName;
        private System.Windows.Forms.TextBox tb_AddPlayerNumber;
        private System.Windows.Forms.ListBox lb_listplayers;
        private System.Windows.Forms.Button btn_AddingTeam;
        private System.Windows.Forms.Button btn_AddingPLayers;
        private System.Windows.Forms.Button btn_RemovePLayer;
    }
}

