﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Take_Home_apdev_week_4
{
    public partial class Form1 : Form
    {
        private List<Team> teams = new List<Team>();
        public Form1()
        {
            InitializeComponent();
            BaseTeams();
            UpdateCountryComboBox();
        }

        public class Team
        {
            public string TeamName { get; set; }
            public string TeamCountry { get; set; }
            public string TeamCity { get; set; }
            public List<Player> Players { get; set; }

            public Team(string teamName, string teamCountry, string teamCity)
            {
                TeamName = teamName;
                TeamCountry = teamCountry;
                TeamCity = teamCity;
                Players = new List<Player>();
            }
        }

        public class Player
        {
            public string PlayerName { get; set; }
            public string PlayerNumber { get; set; }
            public string PlayerPosition { get; set; }

            public Player(string playerName, string playerNumber, string playerPosition)
            {
                PlayerName = playerName;
                PlayerNumber = playerNumber;
                PlayerPosition = playerPosition;
            }

        }

        private void BaseTeams()
        {
            Team team1 = new Team("Manchester City", "English", "Manchester");
            team1.Players.Add(new Player("Ederson", "31", "GK"));
            team1.Players.Add(new Player("Kyle Walker", "02", "DF"));
            team1.Players.Add(new Player("Ruben Dias", "03", "DF"));
            team1.Players.Add(new Player("Nathan Ake", "06", "DF"));
            team1.Players.Add(new Player("Rodri", "16", "MF"));
            team1.Players.Add(new Player("John Stones", "5", "MF"));
            team1.Players.Add(new Player("Phil Foden", "47", "FW"));
            team1.Players.Add(new Player("Bernado Silva", "20", "MF"));
            team1.Players.Add(new Player("Kevin De Bruyne", "17", "MF"));
            team1.Players.Add(new Player("Jeremy Doku", "11", "FW"));
            team1.Players.Add(new Player("Erling Halland", "9", "FW"));
            teams.Add(team1);

            Team team2 = new Team("Manchester United", "English", "Machester");
            team2.Players.Add(new Player("A.Onana", "24", "GK"));
            team2.Players.Add(new Player("V.Lindelof", "2", "DF"));
            team2.Players.Add(new Player("J Evans", "35", "DF"));
            team2.Players.Add(new Player("Raphael Varane", "19", "DF"));
            team2.Players.Add(new Player("D.Dalot", "20", "DF"));
            team2.Players.Add(new Player("K.Mainoo", "37", "MF"));
            team2.Players.Add(new Player("Casemiro", "18", "MF"));
            team2.Players.Add(new Player("Bruno Fernandes", "8", "MF"));
            team2.Players.Add(new Player("S.McTominay", "39", "MF"));
            team2.Players.Add(new Player("Marcus Rashford", "10", "FW"));
            team2.Players.Add(new Player("Alexander Garnacho", "17", "FW"));
            teams.Add(team2);

            Team team3 = new Team("Bayern Munchen", "German", "Munich");
            team3.Players.Add(new Player("M.Neuer", "01", "GK"));
            team3.Players.Add(new Player("J.Kimmich", "06", "DF"));
            team3.Players.Add(new Player("M.De ligt", "04", "DF"));
            team3.Players.Add(new Player("E.Dier", "15", "DF"));
            team3.Players.Add(new Player("R.Guerreiro", "22", "DF"));
            team3.Players.Add(new Player("A.Pavlovic", "45", "MF"));
            team3.Players.Add(new Player("L.Goretzka", "08", "MF"));
            team3.Players.Add(new Player("L.Sane", "10", "FW"));
            team3.Players.Add(new Player("T.Muller", "25", "MF"));
            team3.Players.Add(new Player("J.Musiala", "42", "FW"));
            team3.Players.Add(new Player("Harry Kane", "09", "FW"));
            teams.Add(team3);
        }
        private void UpdateCountryComboBox()
        {
            cb_ChooseCountry.Items.Clear();
            foreach (string country in teams.Select(t => t.TeamCountry).Distinct())
            {
                cb_ChooseCountry.Items.Add(country);
            }
        }

        private void UpdateTeamListBox(string selectedCountry)
        {
            cb_ChooseTeam.Items.Clear();
            foreach (Team team in teams.Where(t => string.Equals(t.TeamCountry, selectedCountry, StringComparison.OrdinalIgnoreCase)))
            {
                cb_ChooseTeam.Items.Add(team.TeamName);
            }
        }

        private void UpdatePlayerListBox(Team selectedTeam)
        {
            lb_listplayers.Items.Clear();
            foreach (Player player in selectedTeam.Players)
            {
                lb_listplayers.Items.Add($"({player.PlayerNumber}) {player.PlayerName}, {player.PlayerPosition}");
            }
        }

        private void btn_AddingTeam_Click(object sender, EventArgs e)
        {
            string teamName = tb_AddTeamName.Text;
            string teamCountry = tb_AddCountry.Text;
            string teamCity = tb_AddCity.Text;

            if (string.IsNullOrEmpty(teamName) || string.IsNullOrEmpty(teamCountry) || string.IsNullOrEmpty(teamCity))
            {
                MessageBox.Show("All Fields Need to be Filled", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (teams.Exists(t => t.TeamName == teamName))
            {
                MessageBox.Show("Team is already exists", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Team newTeam = new Team(teamName, teamCountry, teamCity);
            teams.Add(newTeam);
            UpdateCountryComboBox();
            UpdateTeamListBox(teamCountry);
        }

        private void btn_AddingPLayers_Click(object sender, EventArgs e)
        {
            string playerName = tb_AddPlayerName.Text;
            string playerNumber = tb_AddPlayerNumber.Text;
            string playerPosition = cb_PlayerPosisition.Text;

            if (string.IsNullOrEmpty(playerName) || string.IsNullOrEmpty(playerNumber) || string.IsNullOrEmpty(playerPosition))
            {
                MessageBox.Show("All Fields Need to be Filled", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string selectedTeamName = cb_ChooseTeam.SelectedItem as string;
            if (selectedTeamName == null)
            {   
                MessageBox.Show("All Fields Need to be Filled", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Team selectedTeam = teams.Find(t => t.TeamName == selectedTeamName);

            if (selectedTeam.Players.Exists(p => p.PlayerName == playerName))
            {
                MessageBox.Show("Player already exists in the team", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (selectedTeam.Players.Exists(p => p.PlayerNumber == playerNumber))
            {
                MessageBox.Show("Player number already exists in the team", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            selectedTeam.Players.Add(new Player(playerName, playerNumber, playerPosition));
            UpdatePlayerListBox(selectedTeam);
        }

        private void btn_RemovePLayer_Click(object sender, EventArgs e)
        {
            string selectteam = cb_ChooseTeam.SelectedItem as string;
            if (selectteam == null)
            {
                MessageBox.Show("Please select a team to remove a player", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Team selectedTeam = teams.Find(t => t.TeamName == selectteam);

            if (selectedTeam.Players.Count < 12)
            {
                MessageBox.Show("Unable to Remove Players if Players less than equal 11", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int idx = lb_listplayers.SelectedIndex;
            if (idx == -1)
            {
                MessageBox.Show("Please select a player to remove", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            selectedTeam.Players.RemoveAt(idx);
            UpdatePlayerListBox(selectedTeam);
        }

        private void cb_ChooseCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedCountry = cb_ChooseCountry.SelectedItem as string;
            if (selectedCountry != null)
            {
                UpdateTeamListBox(selectedCountry);
            }
        }

        private void cb_ChooseTeam_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedTeamName = cb_ChooseTeam.SelectedItem as string;
            if (selectedTeamName != null)
            {
                Team selectedTeam = teams.Find(t => t.TeamName == selectedTeamName);
                UpdatePlayerListBox(selectedTeam);
            }
        }
    }
}
